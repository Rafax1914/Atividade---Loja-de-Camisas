package classeDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import lojascamisa.Camisa;

/** 
 * 
 * 
 * @author Rafael Rasquinho
 */
public class CamisaDAO {

    static String URL = "jdbc:mysql://localhost:3306/lojaCamisa";
    static String LOGIN = "root";
    static String SENHA = "Cris1914*";

    public static boolean salvar(Camisa obj) {
        boolean retorno = false;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexao = DriverManager.getConnection(URL, LOGIN, SENHA);
            PreparedStatement comandoSQL = conexao.prepareStatement("insert into camisas(fabricante, marcaCamisa, tamanho) values(?,?,?)");
           
            comandoSQL.setString(1, obj.getFabricante());
            comandoSQL.setString(2, obj.getMarca());
            comandoSQL.setString(3, obj.getTamanho());

            int linhasAfetadas = comandoSQL.executeUpdate();
            if (linhasAfetadas > 0) {
                retorno = true;
            }

            JOptionPane.showMessageDialog(null, "Salvo com sucesso");

        
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return retorno;
    }
  public static ArrayList<Camisa> buscarCamisa(){
        ArrayList<Camisa> listaRetorno = new ArrayList<>();
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexao = DriverManager.getConnection(URL, LOGIN, SENHA);
            PreparedStatement comandoSQL = conexao.prepareStatement("select * from camisas");
            rs = comandoSQL.executeQuery();
            if (rs!=null) {
                while (rs.next()) {
                   Camisa item = new Camisa ();
                    item.setId(rs.getInt("id_produto"));
                    item.setFabricante(rs.getString("fabricante"));
                    item.setMarca(rs.getString("marcaCamisa"));
                    item.setTamanho(rs.getString("tamanho"));
                   
                    listaRetorno.add(item);
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception ex) {

                }
            }
        }
        return listaRetorno;
    }   
public static boolean alterar(Camisa obj){
      boolean retorno = false;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexao = DriverManager.getConnection(URL, LOGIN, SENHA);
            PreparedStatement comandoSQL = conexao.prepareStatement("update camisas set fabricante=?,marcaCamisa=?,tamanho=? where id_produto = ?");
           
            comandoSQL.setString(1, obj.getFabricante());
            comandoSQL.setString(2, obj.getMarca());
            comandoSQL.setString(3, obj.getTamanho());
            comandoSQL.setInt(4,obj.getId());

            int linhasAfetadas = comandoSQL.executeUpdate();
            if (linhasAfetadas > 0) {
                retorno = true;
            }

            JOptionPane.showMessageDialog(null, "Alterado com sucesso");

        
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return retorno;
}
    public static boolean excluir(int id){
      boolean retorno = false;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexao = DriverManager.getConnection(URL, LOGIN, SENHA);
            PreparedStatement comandoSQL = conexao.prepareStatement("delete from camisas where id_produto = ?");
           
            comandoSQL.setInt(1, id);

            int linhasAfetadas = comandoSQL.executeUpdate();
            if (linhasAfetadas > 0) {
                retorno = true;
            }

           

        
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return retorno;
}
     public static ArrayList<Camisa> buscar(String fabricante){
        ArrayList<Camisa> listaRetorno = new ArrayList<>();
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conexao = DriverManager.getConnection(URL, LOGIN, SENHA);
            PreparedStatement comandoSQL = conexao.prepareStatement("select * from camisas where fabricante like ?");
            comandoSQL.setString(1, "%"+fabricante+"%");
            rs = comandoSQL.executeQuery();
                while (rs.next()) {
                   Camisa item = new Camisa ();
                    item.setId(rs.getInt("id_produto"));
                    item.setFabricante(rs.getString("fabricante"));
                    item.setMarca(rs.getString("marcaCamisa"));
                    item.setTamanho(rs.getString("tamanho"));
                   
                    listaRetorno.add(item);
                }
            
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception ex) {

                }
            }
        }
        return listaRetorno;
    }   
   
}
