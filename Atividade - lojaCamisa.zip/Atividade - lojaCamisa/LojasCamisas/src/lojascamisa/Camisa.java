package lojascamisa;

public class Camisa {

    private String fabricante;
    private String marca = "Rafael";
    private String tamanho;
    private int id;

    public Camisa() {
    }
    
    
    public Camisa(String fabricante, String tamanho, int id) {
        this.fabricante = fabricante;
        this.tamanho = tamanho;
        this.id = id;
    }

    public Camisa(String fabricante, String marca, String tamanho) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
